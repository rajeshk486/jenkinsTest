package com.rehab.screen.DTO;

public class UserPreferences {
	
	String preferenceKey;
	String value;
	
	public String getPreferenceKey() {
		return preferenceKey;
	}
	public void setPreferenceKey(String preferenceKey) {
		this.preferenceKey = preferenceKey;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}

}
