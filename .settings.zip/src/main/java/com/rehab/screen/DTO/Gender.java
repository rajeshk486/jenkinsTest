package com.rehab.screen.DTO;

public enum Gender {

	Male,Female,TransGender
}
