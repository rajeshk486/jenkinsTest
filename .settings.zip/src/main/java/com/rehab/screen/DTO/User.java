package com.rehab.screen.DTO;

import java.util.List;

public class User {
	String loginName;
	String email;
	String firstName;
	String lastName;
	List<Contact> contact;
	String password;
	boolean retired;
	String company;
	
	
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}

	public boolean isRetired() {
		return retired;
	}
	public void setRetired(boolean retired) {
		this.retired = retired;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public List<Contact> getContact() {
		return contact;
	}
	public void setContact(List<Contact> contact) {
		this.contact = contact;
	}
	public String getLoginName() {
		return loginName;
	}
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}	
}
/*
 * {
  "loginName": "rockfort",
  "email": "rajesh@hcl.com",
  "firstName": "rajesh",
  "lastName": "kamalanathan",
  "userPreferences": [
    {
      "preferenceKey": "LOCALE",
      "value": "en_US"
    }
    
  ]
} */