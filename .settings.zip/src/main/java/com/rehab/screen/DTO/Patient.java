package com.rehab.screen.DTO;

import java.util.Date;

public class Patient  {

	private String patientFirstName;
	private String patientLastName;
	private String patientFullName;
	private Gender patientGender;
	private Boolean isVaccinated;
	private String patientPhone;
	private String patientEmail;
	private Date patientDOB;
	private Date patientImplantDate;
	private String notes;
	private String comments;
	private long therapistId;
	private String password;
	private long careId;
	
	
	public String getPatientFirstName() {
		return patientFirstName;
	}
	public String getPatientFullName() {
		return patientFullName;
	}
	public void setPatientFullName(String patientFullName) {
		this.patientFullName = patientFullName;
	}
	public Gender getPatientGender() {
		return patientGender;
	}
	public void setPatientGender(Gender patientGender) {
		this.patientGender = patientGender;
	}
	public Boolean getIsVaccinated() {
		return isVaccinated;
	}
	public void setIsVaccinated(Boolean isVaccinated) {
		this.isVaccinated = isVaccinated;
	}
	public Date getPatientDOB() {
		return patientDOB;
	}
	public void setPatientDOB(Date patientDOB) {
		this.patientDOB = patientDOB;
	}
	public Date getPatientImplantDate() {
		return patientImplantDate;
	}
	public void setPatientImplantDate(Date patientImplantDate) {
		this.patientImplantDate = patientImplantDate;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public long getTherapistId() {
		return therapistId;
	}
	public void setTherapistId(long therapistId) {
		this.therapistId = 1;
		//therapistId;
	}
	
	public void setPatientFirstName(String patientFirstName) {
		this.patientFirstName = patientFirstName;
	}
	public String getPatientLastName() {
		return patientLastName;
	}
	public void setPatientLastName(String patientLastName) {
		this.patientLastName = patientLastName;
	}
	public String getPatientPhone() {
		return patientPhone;
	}
	public void setPatientPhone(String patientPhone) {
		this.patientPhone = patientPhone;
	}
	public String getPatientEmail() {
		return patientEmail;
	}
	public void setPatientEmail(String patientEmail) {
		this.patientEmail = patientEmail;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public long getCareId() {
		return careId;
	}
	public void setCareId(long careId) {
		this.careId = careId;
	}
	
}
