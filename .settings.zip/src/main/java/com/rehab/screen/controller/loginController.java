package com.rehab.screen.controller;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

import javax.activation.MimetypesFileTypeMap;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.rehab.screen.DTO.Contact;
import com.rehab.screen.DTO.Patient;
import com.rehab.screen.DTO.User;

@RestController
@PropertySource("classpath:application.properties")
public class loginController {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Value("${url.hostname}")
	private String hostname;

	@Value("${url.filepath}")
	private String filepath;
	
	@Autowired
	HttpServletResponse response;
	
	@GetMapping(value="/")
	public String health()
	{
		return "Health check success!";
	
	}
	@GetMapping(value="/login")
	public ResponseEntity<Map<String,String>> login(@RequestParam(name="name") String username, String password, String org)
	{		
		String encryptedAuthCookies = getBrownStoneAuthcookie(username,password,org);
		logger.info("==== End of  getPasAuthCookies() ====");
		Map<String,String> getuserdetails = GetuserDetails(encryptedAuthCookies,username, org);
		Map<String,String> responseMap= new HashMap<String,String>();
		responseMap.put("cookie",encryptedAuthCookies );
		responseMap.putAll(getuserdetails);
		responseMap.putAll(getPatientId(encryptedAuthCookies, responseMap.get("CareId")));
		return ResponseEntity.ok(responseMap);
	}
	
	@GetMapping(value="/logout")
	public ResponseEntity<Map<String,String>> logout(@RequestParam(name="token") String token)
	{
		Map<String,String> responseMap= new HashMap<String,String>();
		String pasEndpointURL=hostname+":20090/security-web/json/security/logout";
		try {
			logger.info("==== Inside getPasAuthCookies() ====");
			MultiValueMap<String, String> map = new LinkedMultiValueMap<String, String>();
			map.add("token", token);
			RestTemplate restTemplate = new RestTemplate();
			ResponseEntity<String> response = restTemplate.postForEntity(pasEndpointURL, map, String.class);
			System.out.println(response);
			if(((int)response.getStatusCode().value())==200)
			{responseMap.put("status", "Logged Out successfully");}
			else
				responseMap.put("status", "UnSuccessful Log Out");
		}
		catch(Exception e) {responseMap.put("status", "UnSuccessful Log Out");}
		return ResponseEntity.ok(responseMap);
	}
	
	//http://localhost:20082/admin-api/json/userlogon/password/change?userName=rockfort&domainName=hcl.com&password=pas@1234&oldPassword=pas@123
	
	@GetMapping(value="/changepassword")
	public ResponseEntity<Map<String,String>> changepassword(@RequestParam String userName,@RequestParam String domainName,
			@RequestParam String password,@RequestParam String oldPassword)
	{
		Map<String,String> responseMap= new HashMap<String,String>();
		String pasEndpointURL=hostname+":20082/admin-api/json/userlogon/password/change?userName="+userName+"&domainName="
		+domainName+"&password="+password+"&oldPassword="+oldPassword;
		
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		HttpEntity<Object> requestEntity = new HttpEntity<Object>(headers);
		
		try {
			logger.info("==== Inside ChangePassword() ====");
			RestTemplate restTemplate = new RestTemplate();
			ResponseEntity<String> response  = restTemplate.exchange(pasEndpointURL, HttpMethod.POST, requestEntity,
					String.class);
			System.out.println(response);
			if(((int)response.getStatusCode().value())==200)
			{responseMap.put("status", "Password Changed successfully");}
			else
				responseMap.put("status", "UnSuccessful Log Out");
		}
		catch(Exception e) {responseMap.put("status", "Change password UnSuccessful");
		System.out.println(e);}
		return ResponseEntity.ok(responseMap);
	}
	
	@GetMapping(value="/forgotpassword")
	public ResponseEntity<Map<String,String>> forgotpassword(@RequestParam String userName,@RequestParam String domainName)
	{
		Map<String,String> responseMap= new HashMap<String,String>();
		String pasEndpointURL=hostname+":20082/admin-api/json/userlogon/sendForgotPasswordEmail/"+userName+"?domainName="+domainName;
		System.out.println(pasEndpointURL);
		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type", "application/json");
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		HttpEntity<Object> requestEntity = new HttpEntity<Object>(headers);
		
		try {
			logger.info("==== Inside ForgotPassword() ====");
			RestTemplate restTemplate = new RestTemplate();
			ResponseEntity<String> response  = restTemplate.exchange(pasEndpointURL, HttpMethod.POST, requestEntity,String.class);
			System.out.println(response);
			if(((int)response.getStatusCode().value())==200)
			{responseMap.put("status", "Password Change mail sent successfully");}
			else
				responseMap.put("status", "Forgot password UnSuccessful");
		}
		catch(Exception e) {responseMap.put("status", "Forgot password UnSuccessful");
		System.out.println(e);}
		return ResponseEntity.ok(responseMap);
	}
	
	@GetMapping(
			  value = "/signup", consumes = "application/json", produces = "application/json")
	public ResponseEntity<Map<String,String>> signup(@RequestBody User user) throws URISyntaxException
	{
		Map<String,String> responseMap= new HashMap<String,String>();
		RestTemplate restTemplate = new RestTemplate();
		String encryptedAuthCookies="";
		
	    final String baseUrl = hostname+":20082/admin-api/anonymous/json/users/external/createUser/ownerName/hcl.com/roles/patient/id";
	    URI uri = new URI(baseUrl);
	    
	    try {
	    ResponseEntity<String> response = restTemplate.postForEntity(uri, user, String.class);
	  
	    if(((int)response.getStatusCode().value())==200)
		{
	    	 encryptedAuthCookies = getBrownStoneAuthcookie(user.getLoginName(),user.getPassword(),"hcl.com");
	    	
	    	responseMap.put("Message", "User created Successfully!");
	    	
	    }
		else
			responseMap.put("Message", "UnSuccessful User creation");
	    return ResponseEntity.ok(responseMap);
	}
	catch(Exception e) {responseMap.put("Message", e.getMessage());
	System.out.println(e);
	return ResponseEntity.status(400).body(responseMap);}
	
	}
	
	@GetMapping(
			  value = "/signuppatient", consumes = "application/json", produces = "application/json")
	public ResponseEntity<Map<String,String>> signupPatient(@RequestBody Patient patient) throws URISyntaxException
	{
		Map<String,String> responseMap= new HashMap<String,String>();
		User user = setPatient(patient);
			responseMap = userCreation(user);
			if(responseMap.get("Message").equals("Successful User creation"))
			{
			patient.setCareId(Long.parseLong(responseMap.get("CareId")));
			responseMap.putAll( createPatientRecord(patient, responseMap.get("cookie")));
			if(responseMap.get("Statuscode").equals("200"))
				return ResponseEntity.ok(responseMap);
			}
			responseMap.clear();
			responseMap.put("Message", "Successful User creation");
			
			return ResponseEntity.ok(responseMap);
	}
	
	@GetMapping(value="/download")

	public ResponseEntity<Resource> downloadFileFromLocal(@RequestParam String filename)
	{
		File file = new File(filepath.trim()+filename.trim());
		
		MimetypesFileTypeMap mimeTypesMap = new MimetypesFileTypeMap();
		String mimeType = mimeTypesMap.getContentType(file);
		MediaType mediatype = MediaType.valueOf(mimeType);
		
		 Resource fileSystemResource = new FileSystemResource(file);
         return ResponseEntity.ok()
                 .contentType(mediatype)
                 .body(fileSystemResource);
	}

	@GetMapping(value="/downloadfile")

	public ResponseEntity<byte[]> downloadFileFromLocal1(@RequestParam String filename)
	{
		File file = new File(filepath.trim()+filename.trim());
		
		MimetypesFileTypeMap mimeTypesMap = new MimetypesFileTypeMap();
		String mimeType = mimeTypesMap.getContentType(file);
		MediaType mediatype = MediaType.valueOf(mimeType);
		byte[] bytes = null;
		try {
			bytes = Files.readAllBytes(file.toPath());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 Resource fileSystemResource = new FileSystemResource(file);
		 ResponseEntity<byte[]> responseEntity = new ResponseEntity<>(bytes, HttpStatus.OK);
		 return responseEntity;
	}

	//Get user role
	private Map<String,String> GetuserDetails(String BrownStoneAuthCookies,String username, String org)
	{
		String URL=hostname+":20090/security-web/json/users/domainName/"+org+"/userName/"+username; 
		
		ResponseEntity<String> responseOutput=null;
		RestTemplate restTemplate = new RestTemplate();
		String role =null;
		Long id= null;
		Map<String,String> response= new HashMap<>();
		HttpHeaders requestHeaders = new HttpHeaders();
		if (BrownStoneAuthCookies != null && BrownStoneAuthCookies != "") {
			requestHeaders.add("Cookie", "brownstoneauthcookie=" + BrownStoneAuthCookies);
			requestHeaders.setContentType(MediaType.APPLICATION_JSON);
			requestHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		}
		HttpEntity<Object> requestEntity = new HttpEntity<Object>(requestHeaders);
		try {
			responseOutput = restTemplate.exchange(URL, HttpMethod.GET, requestEntity,
					String.class);
			String body = responseOutput.getBody().toString();
			JSONParser parser = new JSONParser();
			JSONObject jsonObject = (JSONObject) parser.parse(body);
			JSONArray jsonArray = (JSONArray) jsonObject.get("roles");
			JSONObject jsonObject1= (JSONObject) jsonArray.get(0);
			role = (String) jsonObject1.get("name");
			System.out.println(jsonObject1.get("name"));
			id = (Long) jsonObject.get("id");
			response.put("role", role);
			response.put("CareId", id.toString());
			}
		catch(Exception e)
		{
			response.clear();
			response.put("Message", "getting user details failed");
			e.printStackTrace();
		}
		
		return response;
	}
	
private Map<String,String> getPatientId(String BrownStoneAuthCookies,String id)
{
	String AppURL=hostname+":20088/api/patient/getpatientid/";
	ResponseEntity<String> responseOutput=null;
	RestTemplate restTemplate = new RestTemplate();
	Map<String,String> response= new HashMap<>();
	HttpHeaders requestHeaders = new HttpHeaders();
	if (BrownStoneAuthCookies != null && BrownStoneAuthCookies != "") {
		requestHeaders.add("Cookie", "brownstoneauthcookie=" + BrownStoneAuthCookies);
		requestHeaders.setContentType(MediaType.APPLICATION_JSON);
		requestHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	}
	HttpEntity<Object> requestEntity = new HttpEntity<Object>(requestHeaders);
	AppURL=AppURL+id;
	try {
	responseOutput =  restTemplate.exchange(AppURL, HttpMethod.POST, requestEntity,
			String.class);
	System.out.println(responseOutput);
	response.put("PatientId", responseOutput.getBody().toString());
	}
	catch(Exception e)
	{
		response.clear();
		response.put("Message", "getting PatientID details failed");
		e.printStackTrace();
	}
	return response;
}

private String getBrownStoneAuthcookie(String username,String password, String org )
{
	String pasEndpointURL=hostname+":20090/security-web/json/security/login";
	System.out.println(pasEndpointURL);
	ResponseEntity<String> response = null;
	String encryptedAuthCookies="";
			try {
		logger.info("==== Inside getPasAuthCookies() ====");
		RestTemplate restTemplate = new RestTemplate();
		MultiValueMap<String, String> map = new LinkedMultiValueMap<String, String>();
		map.add("Content-Type", " application/x-www-erform-urlencoded");
		map.add("j_username", username);
		map.add("j_password", password);
		map.add("org", org);
		//MediaType.APPLICATION_FORM_URLENCODED
		response = restTemplate.postForEntity(pasEndpointURL, map, String.class);
		if (response != null) {
			encryptedAuthCookies = response.getBody();
			logger.info("----------------PAS BROWNSTONE COOKIES----------------");
			logger.info("PAS BROWNSTONE COOKIES,{}" + encryptedAuthCookies);
			logger.info("----------------PAS BROWNSTONE COOKIES----------------");
			
		}

	} catch (Exception e) {
		logger.info("Exception",""+e.getMessage());
		e.printStackTrace();
		
	}
return encryptedAuthCookies;			
}
private User setPatient(Patient patient)
{
	User user = new User();
	user.setEmail(patient.getPatientEmail());
	user.setLoginName(patient.getPatientEmail());
	user.setFirstName(patient.getPatientFirstName());
	user.setLastName(patient.getPatientLastName());
	user.setCompany(null);
	user.setPassword(patient.getPassword());
	Contact contactobj = new Contact();
	contactobj.setMobile(patient.getPatientPhone());
	List<Contact> contact= new ArrayList<Contact>() {
	{add(contactobj);}};
	//contact.add(contactobj);
	user.setContact(contact);
	user.setRetired(false);
	
	return user;
}

//creating user and sending their id and role with this
private Map<String,String> userCreation(User user) throws URISyntaxException
{
	
	Map<String,String> responseMap= new HashMap<String,String>();
	RestTemplate restTemplate = new RestTemplate();
	String encryptedAuthCookies="";
     
    final String baseUrl = hostname+":20082/admin-api/anonymous/json/users/external/createUser/ownerName/hcl.com/roles/patient/id";
    URI uri = new URI(baseUrl);
    
  
    ResponseEntity<String> response = restTemplate.postForEntity(uri, user, String.class);
    int statuscode = response.getStatusCode().value();
    //int statuscode=201;

	if(201 == statuscode)
	{
    	encryptedAuthCookies = getBrownStoneAuthcookie(user.getLoginName(),user.getPassword(),"hcl.com");
    	
    	responseMap.putAll(GetuserDetails(encryptedAuthCookies,user.getEmail(),"hcl.com"));
    	responseMap.put("Message", "Successful User creation");
    	responseMap.put("cookie",encryptedAuthCookies);
    	
    }
	else
		responseMap.put("Message", "UnSuccessful User creation");
	
	return responseMap;    
}

private Map<String,String> createPatientRecord(Patient patient,String encryptedAuthCookies)
{
	Map<String,String> responseMap= new HashMap<String,String>();
	ResponseEntity<String> responseOutput;
	RestTemplate restTemplate = new RestTemplate();
	HttpHeaders requestHeaders = new HttpHeaders();
	int Statuscode=0;
	if (encryptedAuthCookies != null && encryptedAuthCookies != "") {
		requestHeaders.add("Cookie", "brownstoneauthcookie=" + encryptedAuthCookies);
		requestHeaders.setContentType(MediaType.APPLICATION_JSON);
		requestHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	}
	HttpEntity<Object> requestEntity = new HttpEntity<Object>(requestHeaders);
	try {
			 HttpEntity<Patient> request = new HttpEntity<>(patient, requestHeaders);
		responseOutput = restTemplate.exchange(hostname+":20088/api/patient/savePatient", HttpMethod.POST, request,
				String.class);
		Statuscode= responseOutput.getStatusCode().value();
		responseMap.put("Statuscode",Statuscode+"");
		/*JSONParser parser = new JSONParser();
		JSONObject jsonObject = (JSONObject) parser.parse(responseOutput.getBody().toString());
		Long PatientId = (Long) jsonObject.get("id");
		responseMap.put("PatientId",PatientId.toString());
		System.out.println(responseOutput);
		responseOutput = restTemplate.exchange("http://localhost:20088/api/patient/health", HttpMethod.GET, requestEntity,
				String.class);
		System.out.println(responseOutput);*/
		
	}
	catch(Exception e) {
		responseMap.clear();
	responseMap.put("Message", "User not Created on Application");
	System.out.println(e);
	}
	return responseMap;
}
}
