package com.rehab.screen.Rehab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.rehab.screen.controller")

public class RehabApplication {

	public static void main(String[] args) {
		SpringApplication.run(RehabApplication.class, args);
	}

}
