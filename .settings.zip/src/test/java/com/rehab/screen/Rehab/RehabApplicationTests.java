package com.rehab.screen.Rehab;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RehabApplicationTests {

	@Test
	void contextLoads() {
	}

}
